type token =
  | INT of (int)
  | IDENT of (string)
  | DEF
  | AVANCE
  | RECULE
  | GAUCHE
  | DROITE
  | EFFACE
  | DESSINE
  | DEPLACE
  | DEUXPOINTS
  | PNTVRG
  | POINT
  | REPETE
  | CROCHOU
  | CROCHFE
  | PLUS
  | MOINS
  | MULT
  | DIV
  | PAROU
  | PARFE
  | SI
  | ALORS
  | SINON
  | FINSI
  | EGAL
  | SUP
  | INF
  | EOF

open Parsing;;
let _ = parse_error;;
# 2 "logo_parser.mly"
(***************************************)
(* Analyseur syntaxique pour Logo      *)
(***************************************)

open Logo_ast
# 42 "logo_parser.ml"
let yytransl_const = [|
  259 (* DEF *);
  260 (* AVANCE *);
  261 (* RECULE *);
  262 (* GAUCHE *);
  263 (* DROITE *);
  264 (* EFFACE *);
  265 (* DESSINE *);
  266 (* DEPLACE *);
  267 (* DEUXPOINTS *);
  268 (* PNTVRG *);
  269 (* POINT *);
  270 (* REPETE *);
  271 (* CROCHOU *);
  272 (* CROCHFE *);
  273 (* PLUS *);
  274 (* MOINS *);
  275 (* MULT *);
  276 (* DIV *);
  277 (* PAROU *);
  278 (* PARFE *);
  279 (* SI *);
  280 (* ALORS *);
  281 (* SINON *);
  282 (* FINSI *);
  283 (* EGAL *);
  284 (* SUP *);
  285 (* INF *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* INT *);
  258 (* IDENT *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\003\000\003\000\003\000\003\000\003\000\005\000\
\005\000\005\000\005\000\005\000\005\000\005\000\004\000\004\000\
\004\000\004\000\004\000\004\000\002\000\002\000\002\000\000\000"

let yylen = "\002\000\
\002\000\002\000\003\000\001\000\003\000\005\000\007\000\002\000\
\002\000\002\000\002\000\001\000\001\000\001\000\001\000\002\000\
\005\000\005\000\005\000\005\000\005\000\005\000\005\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\012\000\
\013\000\014\000\000\000\000\000\024\000\000\000\004\000\000\000\
\015\000\000\000\000\000\008\000\009\000\010\000\011\000\000\000\
\000\000\000\000\000\000\001\000\002\000\003\000\016\000\000\000\
\000\000\000\000\000\000\005\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\006\000\000\000\000\000\000\000\000\000\017\000\018\000\
\019\000\020\000\021\000\022\000\023\000\000\000\007\000"

let yydgoto = "\002\000\
\013\000\026\000\014\000\020\000\015\000"

let yysindex = "\008\000\
\039\255\000\000\015\255\255\254\255\254\255\254\255\254\000\000\
\000\000\000\000\255\254\253\254\000\000\001\000\000\000\255\254\
\000\000\019\255\255\254\000\000\000\000\000\000\000\000\012\255\
\255\254\008\255\039\255\000\000\000\000\000\000\000\000\006\255\
\039\255\002\255\039\255\000\000\255\254\255\254\255\254\255\254\
\251\254\255\254\255\254\255\254\003\255\016\255\028\255\029\255\
\030\255\000\000\032\255\033\255\034\255\039\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\249\254\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\235\255\253\255\000\000"

let yytablesize = 270
let yytable = "\017\000\
\029\000\021\000\022\000\023\000\027\000\036\000\027\000\024\000\
\001\000\018\000\050\000\041\000\030\000\045\000\027\000\032\000\
\016\000\025\000\063\000\019\000\031\000\034\000\037\000\038\000\
\039\000\040\000\033\000\054\000\042\000\043\000\044\000\035\000\
\062\000\046\000\047\000\048\000\049\000\055\000\051\000\052\000\
\053\000\003\000\004\000\005\000\006\000\007\000\008\000\009\000\
\010\000\056\000\057\000\058\000\011\000\059\000\060\000\061\000\
\000\000\000\000\000\000\000\000\000\000\012\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\027\000\028\000"

let yycheck = "\001\001\
\000\000\005\000\006\000\007\000\012\001\027\000\012\001\011\000\
\001\000\011\001\016\001\033\000\016\000\035\000\012\001\019\000\
\002\001\021\001\026\001\021\001\002\001\025\000\017\001\018\001\
\019\001\020\001\015\001\025\001\027\001\028\001\029\001\024\001\
\054\000\037\000\038\000\039\000\040\000\022\001\042\000\043\000\
\044\000\003\001\004\001\005\001\006\001\007\001\008\001\009\001\
\010\001\022\001\022\001\022\001\014\001\022\001\022\001\022\001\
\255\255\255\255\255\255\255\255\255\255\023\001\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\012\001\013\001"

let yynames_const = "\
  DEF\000\
  AVANCE\000\
  RECULE\000\
  GAUCHE\000\
  DROITE\000\
  EFFACE\000\
  DESSINE\000\
  DEPLACE\000\
  DEUXPOINTS\000\
  PNTVRG\000\
  POINT\000\
  REPETE\000\
  CROCHOU\000\
  CROCHFE\000\
  PLUS\000\
  MOINS\000\
  MULT\000\
  DIV\000\
  PAROU\000\
  PARFE\000\
  SI\000\
  ALORS\000\
  SINON\000\
  FINSI\000\
  EGAL\000\
  SUP\000\
  INF\000\
  EOF\000\
  "

let yynames_block = "\
  INT\000\
  IDENT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 49 "logo_parser.mly"
                      ( _1 )
# 241 "logo_parser.ml"
               : Logo_ast.t_instr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 50 "logo_parser.mly"
                      ( _1 )
# 248 "logo_parser.ml"
               : Logo_ast.t_instr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 54 "logo_parser.mly"
                                   ( Define(_2, _3) )
# 256 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'commande) in
    Obj.repr(
# 55 "logo_parser.mly"
                                   ( Cmd(_1) )
# 263 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'instruction) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'instruction) in
    Obj.repr(
# 56 "logo_parser.mly"
                                   ( Seq(_1, _3) )
# 271 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 57 "logo_parser.mly"
                                                  ( Repeat(_2, _4) )
# 279 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 5 : Logo_ast.t_bexpr) in
    let _4 = (Parsing.peek_val __caml_parser_env 3 : 'instruction) in
    let _6 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 58 "logo_parser.mly"
                                                           ( If(_2, _4, _6) )
# 288 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 62 "logo_parser.mly"
                      ( Forward(_2) )
# 295 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 63 "logo_parser.mly"
                      ( Backward(_2) )
# 302 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 64 "logo_parser.mly"
                      ( Left(_2) )
# 309 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 65 "logo_parser.mly"
                      ( Right(_2) )
# 316 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 66 "logo_parser.mly"
                      ( Clear )
# 322 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 67 "logo_parser.mly"
                      ( PenDown )
# 328 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 68 "logo_parser.mly"
                      ( PenUp )
# 334 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 72 "logo_parser.mly"
                     ( Cst(_1) )
# 341 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 73 "logo_parser.mly"
                     ( Var(_2) )
# 348 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 74 "logo_parser.mly"
                                            ( Add(_2, _4) )
# 356 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 75 "logo_parser.mly"
                                            ( Mns(_2, _4) )
# 364 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 76 "logo_parser.mly"
                                            ( Mul(_2, _4) )
# 372 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 77 "logo_parser.mly"
                                            ( Div(_2, _4) )
# 380 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 81 "logo_parser.mly"
                                           ( Cmp(Egal, _2, _4) )
# 388 "logo_parser.ml"
               : Logo_ast.t_bexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 82 "logo_parser.mly"
                                           ( Cmp(Sup, _2, _4) )
# 396 "logo_parser.ml"
               : Logo_ast.t_bexpr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 83 "logo_parser.mly"
                                           ( Cmp(Inf, _2, _4) )
# 404 "logo_parser.ml"
               : Logo_ast.t_bexpr))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Logo_ast.t_instr)
