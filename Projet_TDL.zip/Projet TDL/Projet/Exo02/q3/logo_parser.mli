type token =
  | INT of (int)
  | IDENT of (string)
  | DEF
  | AVANCE
  | RECULE
  | GAUCHE
  | DROITE
  | EFFACE
  | DESSINE
  | DEPLACE
  | DEUXPOINTS
  | PNTVRG
  | POINT
  | REPETE
  | CROCHOU
  | CROCHFE
  | PLUS
  | MOINS
  | MULT
  | DIV
  | PAROU
  | PARFE
  | EOF

val main :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Logo_ast.t_instr
