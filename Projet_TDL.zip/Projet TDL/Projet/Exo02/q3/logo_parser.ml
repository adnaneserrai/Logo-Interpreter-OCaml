type token =
  | INT of (int)
  | IDENT of (string)
  | DEF
  | AVANCE
  | RECULE
  | GAUCHE
  | DROITE
  | EFFACE
  | DESSINE
  | DEPLACE
  | DEUXPOINTS
  | PNTVRG
  | POINT
  | REPETE
  | CROCHOU
  | CROCHFE
  | PLUS
  | MOINS
  | MULT
  | DIV
  | PAROU
  | PARFE
  | EOF

open Parsing;;
let _ = parse_error;;
# 2 "logo_parser.mly"
(***************************************)
(* Analyseur syntaxique pour Logo      *)
(***************************************)

open Logo_ast
# 35 "logo_parser.ml"
let yytransl_const = [|
  259 (* DEF *);
  260 (* AVANCE *);
  261 (* RECULE *);
  262 (* GAUCHE *);
  263 (* DROITE *);
  264 (* EFFACE *);
  265 (* DESSINE *);
  266 (* DEPLACE *);
  267 (* DEUXPOINTS *);
  268 (* PNTVRG *);
  269 (* POINT *);
  270 (* REPETE *);
  271 (* CROCHOU *);
  272 (* CROCHFE *);
  273 (* PLUS *);
  274 (* MOINS *);
  275 (* MULT *);
  276 (* DIV *);
  277 (* PAROU *);
  278 (* PARFE *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* INT *);
  258 (* IDENT *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\002\000\002\000\002\000\002\000\004\000\004\000\
\004\000\004\000\004\000\004\000\004\000\003\000\003\000\003\000\
\003\000\003\000\003\000\000\000"

let yylen = "\002\000\
\002\000\002\000\003\000\001\000\003\000\005\000\002\000\002\000\
\002\000\002\000\001\000\001\000\001\000\001\000\002\000\005\000\
\005\000\005\000\005\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\011\000\
\012\000\013\000\000\000\020\000\000\000\004\000\000\000\014\000\
\000\000\000\000\007\000\008\000\009\000\010\000\000\000\000\000\
\001\000\002\000\003\000\015\000\000\000\000\000\005\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\006\000\016\000\017\000\018\000\019\000"

let yydgoto = "\002\000\
\012\000\013\000\019\000\014\000"

let yysindex = "\005\000\
\030\255\000\000\005\255\255\254\255\254\255\254\255\254\000\000\
\000\000\000\000\255\254\000\000\001\000\000\000\255\254\000\000\
\012\255\255\254\000\000\000\000\000\000\000\000\001\255\030\255\
\000\000\000\000\000\000\000\000\004\255\030\255\000\000\255\254\
\255\254\255\254\255\254\253\254\251\254\252\254\003\255\006\255\
\000\000\000\000\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\237\255\253\255\000\000"

let yytablesize = 270
let yytable = "\016\000\
\026\000\020\000\021\000\022\000\031\000\001\000\015\000\023\000\
\024\000\017\000\036\000\027\000\041\000\028\000\029\000\030\000\
\042\000\043\000\000\000\018\000\032\000\033\000\034\000\035\000\
\044\000\000\000\000\000\045\000\037\000\038\000\039\000\040\000\
\003\000\004\000\005\000\006\000\007\000\008\000\009\000\010\000\
\000\000\000\000\000\000\011\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\024\000\025\000"

let yycheck = "\001\001\
\000\000\005\000\006\000\007\000\024\000\001\000\002\001\011\000\
\012\001\011\001\030\000\015\000\016\001\002\001\018\000\015\001\
\022\001\022\001\255\255\021\001\017\001\018\001\019\001\020\001\
\022\001\255\255\255\255\022\001\032\000\033\000\034\000\035\000\
\003\001\004\001\005\001\006\001\007\001\008\001\009\001\010\001\
\255\255\255\255\255\255\014\001\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\012\001\013\001"

let yynames_const = "\
  DEF\000\
  AVANCE\000\
  RECULE\000\
  GAUCHE\000\
  DROITE\000\
  EFFACE\000\
  DESSINE\000\
  DEPLACE\000\
  DEUXPOINTS\000\
  PNTVRG\000\
  POINT\000\
  REPETE\000\
  CROCHOU\000\
  CROCHFE\000\
  PLUS\000\
  MOINS\000\
  MULT\000\
  DIV\000\
  PAROU\000\
  PARFE\000\
  EOF\000\
  "

let yynames_block = "\
  INT\000\
  IDENT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 46 "logo_parser.mly"
                      ( _1 )
# 214 "logo_parser.ml"
               : Logo_ast.t_instr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 47 "logo_parser.mly"
                      ( _1 )
# 221 "logo_parser.ml"
               : Logo_ast.t_instr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 51 "logo_parser.mly"
                                   ( Define(_2, _3) )
# 229 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'commande) in
    Obj.repr(
# 52 "logo_parser.mly"
                                   ( Cmd(_1) )
# 236 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'instruction) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'instruction) in
    Obj.repr(
# 53 "logo_parser.mly"
                                   ( Seq(_1, _3) )
# 244 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'instruction) in
    Obj.repr(
# 54 "logo_parser.mly"
                                                  ( Repeat(_2, _4) )
# 252 "logo_parser.ml"
               : 'instruction))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 58 "logo_parser.mly"
                      ( Forward(_2) )
# 259 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 59 "logo_parser.mly"
                      ( Backward(_2) )
# 266 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 60 "logo_parser.mly"
                      ( Left(_2) )
# 273 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'expression) in
    Obj.repr(
# 61 "logo_parser.mly"
                      ( Right(_2) )
# 280 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 62 "logo_parser.mly"
                      ( Clear )
# 286 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 63 "logo_parser.mly"
                      ( PenDown )
# 292 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    Obj.repr(
# 64 "logo_parser.mly"
                      ( PenUp )
# 298 "logo_parser.ml"
               : 'commande))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 68 "logo_parser.mly"
                     ( Cst(_1) )
# 305 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 69 "logo_parser.mly"
                     ( Var(_2) )
# 312 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 70 "logo_parser.mly"
                                            ( Add(_2, _4) )
# 320 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 71 "logo_parser.mly"
                                            ( Mns(_2, _4) )
# 328 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 72 "logo_parser.mly"
                                            ( Mul(_2, _4) )
# 336 "logo_parser.ml"
               : 'expression))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'expression) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'expression) in
    Obj.repr(
# 73 "logo_parser.mly"
                                            ( Div(_2, _4) )
# 344 "logo_parser.ml"
               : 'expression))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Logo_ast.t_instr)
