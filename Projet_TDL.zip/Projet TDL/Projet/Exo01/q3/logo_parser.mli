type token =
  | INT of (int)
  | IDENT of (string)
  | DEF
  | AVANCE
  | RECULE
  | GAUCHE
  | DROITE
  | EFFACE
  | DESSINE
  | DEPLACE
  | DEUXPOINTS
  | PNTVRG
  | POINT
  | EOF

val main :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Logo_ast.t_instr
